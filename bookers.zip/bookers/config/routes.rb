Rails.application.routes.draw do
 root :to => 'books#top'
 resources :books
end