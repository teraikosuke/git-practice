# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '0aec65da074a639cb96b443eabfce530871fc38876b0a16ab48ed74a217aa3edb133b3eda2ebe4b5e3b163da960d02a7cf956f1237ae2bfc0b327c626a70306d'